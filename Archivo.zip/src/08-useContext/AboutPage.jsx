export const AboutPage = () => {
    return (
      <>
          <h1>AboutPage</h1>
          <hr />
      </>
    )
  }
  