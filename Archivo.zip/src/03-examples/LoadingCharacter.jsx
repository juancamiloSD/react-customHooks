export const LoadingCharacter = () => {
  return (
    <>
        <div className="alert alert-info text-center">
            Loading...
        </div>
    </>
  )
}
